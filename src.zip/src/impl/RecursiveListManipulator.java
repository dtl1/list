package impl;

import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import common.InvalidIndexException;
import common.InvalidListException;
import common.ListNode;
import interfaces.IFilterCondition;
import interfaces.IListManipulator;
import interfaces.IMapTransformation;
import interfaces.IReduceOperator;

/**
 * This class represents the recursive implementation of the IListManipulator interface.
 */
public class RecursiveListManipulator implements IListManipulator {

    @Override
    public int size(ListNode head) {
        if (head == null)
            return 0;
        else
            return 1 + size(head.next);
    }

    @Override
    public boolean contains(ListNode head, Object element) {

        if (head == null)
            return false;

        if (head.element.equals(element))
            return true;

        return contains(head.next, element);
    }

    @Override
    public int count(ListNode head, Object element) {
        if (head == null)
            return 0;


        if (head.element.equals(element)) {
            return 1 + count(head.next, element);
        } else {
            return count(head.next, element);
        }

    }

    @Override
    public String convertToString(ListNode head) {
        if (head == null)
            return "";


        if (head.next == null)
            return head.element.toString();


        return head.element.toString() + "," + convertToString(head.next);
    }

    @Override
    public Object getFromFront(ListNode head, int n) throws InvalidIndexException {
        if (n < 0 || n >= size(head) || head == null)
            throw new InvalidIndexException();

        if (n == 0) {
            return head.element;
        } else {
            return getFromFront(head.next, n - 1);
        }

    }

    @Override
    public Object getFromBack(ListNode head, int n) throws InvalidIndexException {

        if (n < 0 || n >= size(head) || head == null)
            throw new InvalidIndexException();


        if (n == size(head) - 1) {
            return head.element;
        } else {
            return getFromBack(head.next, n);
        }

    }

    @Override
    public boolean equals(ListNode head1, ListNode head2) {

        if (size(head1) != size(head2))
            return false;

        if (head1 == null && head2 == null)
            return true;

        if (head1 != null && head2 != null)
            return (head1.element.equals(head2.element)) && equals(head1.next, head2.next);

        return false;
    }

    @Override
    public boolean containsDuplicates(ListNode head) {

        if (head == null)
            return false;

       if(contains(head.next, head.element)){
           return true;
       } else{
           return containsDuplicates(head.next);
       }

    }

    public ListNode append(ListNode head1, ListNode head2) {
        if (head1 == null)
            return head2;

        if (head1.next == null) {
            head1.next = head2;
        }
        else {
            append(head1.next, head2);
        }

        return head1;
    }


    @Override
    public ListNode reverse(ListNode head) {

            if (head == null || head.next == null)
                return head;


            ListNode temp = reverse(head.next);
            head.next.next = head;


            head.next = null;


            return temp;

    }


    @Override
    public ListNode split(ListNode head, int n) throws InvalidIndexException, InvalidListException {
        if (head == null || size(head) <= 1)
            throw new InvalidListException();


        if (n <= 0 || n >= size(head))
            throw new InvalidIndexException();


        return split(head, n, null);
    }

    private ListNode split(ListNode head, int n, ListNode newList) {
        if (n == 0)
            return new ListNode(newList, new ListNode(head));


        newList = append(newList, new ListNode(head.element));

        return split(head.next, n - 1, newList);
    }

    @Override
    public ListNode flatten(ListNode head) {
        return flatten(head, null);
    }

    private ListNode flatten(ListNode head, ListNode newList) {
        if (head == null)
            return newList;


        newList = append(newList, (ListNode) head.element);
        return flatten(head.next, newList);
    }


    @Override
    public boolean isCircular(ListNode head) {
        if (head == null || head.next == null) {
            return false;
        }
        return isCircular(head, head.next.next, head.next);
    }

    private boolean isCircular(ListNode head, ListNode fast, ListNode slow) {
        if (fast == null || fast.next == null) {
            return false;
        }

        if (fast == head) {
            return true;
        }

        if (fast == slow) {
            return false;
        }

        return isCircular(head, fast.next.next, slow.next);
    }

    @Override
    public boolean containsCycles(ListNode head) {
       if(head == null)
           return false;

       if (isCircular(head))
                return true;

        return containsCycles(head.next);
    }

    @Override
    public ListNode sort(ListNode head, Comparator comparator) {
        if (head == null || head.next == null)
            return head;


        ListNode middle = getMid(head);
        ListNode postMid = middle.next;

        middle.next = null;

        return sort(comparator, sort(head, comparator), sort(postMid, comparator));
    }

    private ListNode sort(Comparator comparator, ListNode left, ListNode right) {
        ListNode result = null;

        if (left == null)
            return right;


        if (right == null)
            return left;


        if (comparator.compare(left.element, right.element) <= 0) {
            result = left;
            result.next = sort(comparator, left.next, right);
        }
        else {
            result = right;
            result.next = sort(comparator, left, right.next);
        }

        return result;
    }

    private ListNode getMid(ListNode head) {
        if (head == null)
            return head;


        ListNode fast = head;
        ListNode slow = head;

        while (fast.next != null && fast.next.next != null) {
            fast = fast.next.next;
            slow = slow.next;
        }

        return slow;
    }


    @Override
    public ListNode map(ListNode head, IMapTransformation transformation) {
        return map(head, transformation, null);
    }

    private ListNode map(ListNode head, IMapTransformation transformation, ListNode newList) {
        if (head == null)
            return newList;


        newList = append(newList, new ListNode(transformation.transform(head.element)));
        return map(head.next, transformation, newList);
    }

    @Override
    public Object reduce(ListNode head, IReduceOperator operator, Object initial) {
        if(head == null)
            return initial;

        return reducePriv(head, operator, head.element);
    }

    private Object reducePriv(ListNode head, IReduceOperator operator, Object object) {
        if(head == null || head.next == null)
            return object;

        object = operator.operate(object, head.next.element);
        return reducePriv(head.next, operator, object);
    }


    @Override
    public ListNode filter(ListNode head, IFilterCondition condition) {
        return filter(head, condition, null);
    }

    private ListNode filter(ListNode head, IFilterCondition condition, ListNode newList) {
        if(head == null)
            return newList;

        if(condition.isSatisfied(head.element))
            newList = append(newList, new ListNode(head.element));

        return filter(head.next, condition, newList);
    }

}
