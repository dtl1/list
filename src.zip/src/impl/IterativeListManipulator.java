package impl;

import java.util.*;

import common.InvalidIndexException;
import common.InvalidListException;
import common.ListNode;
import interfaces.IFilterCondition;
import interfaces.IListManipulator;
import interfaces.IMapTransformation;
import interfaces.IReduceOperator;

/**
 * This class represents the iterative implementation of the IListManipulator interface.
 */
public class IterativeListManipulator implements IListManipulator {


    @Override
    public int size(ListNode head) {

        int size = 0;

        //increment size on each iteration of the list
        while (head != null) {
            size++;
            head = head.next;
        }

        return size;
    }

    @Override
    public boolean contains(ListNode head, Object element) {
        //iterate through list and check the element
        while (head != null) {

            //return true if the elements match
            if (head.element.equals(element))
                return true;

            head = head.next;

        }

        //return false if the element isn't found
        return false;
    }

    @Override
    public int count(ListNode head, Object element) {

        int count = 0;

        //iterate through the list
        while (head != null) {
            //increment count if the elements match
            if (head.element.equals(element))
                count++;

            head = head.next;
        }

        return count;
    }

    @Override
    public String convertToString(ListNode head) {

        //create a new string builder object which will hold the final string
        StringBuilder listStr = new StringBuilder();

        while (head != null) {

            //on every iteration other than the first, append a comma to the string builder
            if (!listStr.toString().equals(""))
                listStr.append(",");

            //on every iteration append the string value of the element to the builder
            listStr.append(head.element.toString());

            head = head.next;
        }

        //return the string value of the builder
        return listStr.toString();
    }

    @Override
    public Object getFromFront(ListNode head, int n) throws InvalidIndexException {

        //check to see if the index is invalid
        if (n < 0 || n >= size(head) || head == null)
            throw new InvalidIndexException();

        //for loop to iterate the loop to the nth index
        for (int m = 0; m < n; m++)
            head = head.next;

        //return the element of the nth index
        return head.element;
    }

    @Override
    public Object getFromBack(ListNode head, int n) throws InvalidIndexException {

        //check index
        if (n < 0 || n >= size(head) || head == null)
            throw new InvalidIndexException();

        //create new var that is the size of the list minus 1 minus n
        int o = size(head) - 1 - n;

        //now a for loop can be used to loop up to the correct element
        for (int m = 0; m < o; m++)
            head = head.next;


        return head.element;

    }

    @Override
    public boolean equals(ListNode head1, ListNode head2) {

        //if the sizes of the 2 lists are not equal then return false
        if (size(head1) != size(head2))
            return false;

        while (head1 != null) {

            //if at any point the current elements are not equal then return false
            if (!head1.element.equals(head2.element))
                return false;

            //iterate heads
            head1 = head1.next;
            head2 = head2.next;
        }

        //if the end is reached and the lists are equal then return true
        return true;

    }

    @Override
    public boolean containsDuplicates(ListNode head) {

        while (head != null) {
            //for each iteration, call the contains method and pass in the next node
            //and the element of the current node
            if (contains(head.next, head.element))
                //if contains returns true then a duplicate is found so return true
                return true;

            head = head.next;
        }

        //otherwise if no duplicates found and while loop terminated then return false
        return false;

    }

    @Override
    public ListNode append(ListNode head1, ListNode head2) {

        //if one of the heads is null, return the other, and if they are both null
        //then null is returned
        if (head1 == null) {
            return head2;
        } else if (head2 == null) {
            return head1;
        }

        //create copy of head of first list
        ListNode newList = head1;

        //traverse to tail of list
        while (head1.next != null)
            head1 = head1.next;


        //set tail next to head of other list
        head1.next = head2;

        //returned copied head which is a combination of both lists
        return newList;

    }

    @Override
    public ListNode reverse(ListNode head) {

        //create 3 nodes, current is set to the head
        ListNode prev = null;
        ListNode current = head;
        ListNode next;

        while (current != null) {
            //store next node
            next = current.next;

            //change the next of current to previous
            current.next = prev;

            //move previous and current one step forward
            prev = current;
            current = next;
        }

        //return previous which is the head of the new reversed list
        return prev;

    }

    @Override
    public ListNode split(ListNode head, int n) throws InvalidIndexException, InvalidListException {

        if (head == null || head.next == null)
            throw new InvalidListException();

        if (n <= 0 || n >= size(head))
            throw new InvalidIndexException();


        ListNode newList = new ListNode(head.element);
        head = head.next;


        for (int m = 0; m < n - 1; m++) {
            ListNode tempNode = new ListNode(head.element);
            newList = append(newList, tempNode);
            head = head.next;
        }


        return new ListNode(newList, new ListNode(head));
    }

    @Override
    public ListNode flatten(ListNode head) {
        if (head == null)
            return null;

        ListNode newList = null;

        while (head != null) {
            newList = append(newList, (ListNode) head.element);
            head = head.next;
        }

        return newList;

    }

    @Override
    public boolean isCircular(ListNode head) {

        if (head == null)
            return false;

        ListNode slow = head;
        ListNode fast = head;

        while (fast != null && fast.next != null) {
            fast = fast.next.next;
            slow = slow.next;

            if (fast == head)
                return true;


            if (fast == slow)
                return false;

        }
        return false;
    }

    @Override
    public boolean containsCycles(ListNode head) {

        if (head == null)
            return false;


        while (head != null) {

            if (isCircular(head))
                return true;

            head = head.next;

        }


        return false;
    }

    @Override
    public ListNode sort(ListNode head, Comparator comparator) {
        ListNode newList = head;

        while (newList != null){
            ListNode  minimum = newList;
            ListNode compare = newList.next;

            while (compare != null){

                if(comparator.compare(minimum.element, compare.element) >= 0)
                    minimum = compare;


                compare = compare.next;
            }

            Object swap = minimum.element;
            minimum.element = newList.element;
            newList.element = swap;
            newList = newList.next;

        }

        return head;
    }

    @Override
    public ListNode map(ListNode head, IMapTransformation transformation) {

        if(head == null)
            return null;


        ListNode newList = null;

        while(head != null){

            newList = append(newList, new ListNode(transformation.transform(head.element)));

            head = head.next;

        }

        return newList;




    }

    @Override
    public Object reduce(ListNode head, IReduceOperator operator, Object initial) {
        if(head == null)
            return initial;

        Object object = head.element;


        while(head != null && head.next != null){

           object = operator.operate(object, head.next.element);
           head = head.next;

        }

        return object;

    }

    @Override
    public ListNode filter(ListNode head, IFilterCondition condition) {
        if(head == null)
            return null;


        ListNode newList = null;

        while(head != null){

            if(condition.isSatisfied(head.element))
            newList = append(newList, new ListNode(head.element));

            head = head.next;

        }

        return newList;

    }

}
