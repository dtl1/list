package common;


/**
 * Exception class indicating that an invalid index has been specified.
 *
 */
public class InvalidIndexException extends Exception {

}
