package common;


/**
 * Exception class indicating that an invalid list has been specified.
 *
 */
public class InvalidListException extends Exception {

}
